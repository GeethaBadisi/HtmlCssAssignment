export const products = [
    {
        productId: '1',
        productName: 'Christmas tree',
        image: '../images/tree.jpg'
    },
    {
        productId: '2',
        productName: 'Santa outfit',
        image: '../images/santa.jpg'
    },
    {
        productId: '3',
        productName: 'Christmas cake',
        image: '../images/cake.jpg'
    },
    {
        productId: '4',
        productName: 'Christmas Balls',
        image: '../images/balls.jpg'
    },
    {
        productId: '5',
        productName: 'Christmas Bells',
        image: '../images/bells.jpg'
    },
    {
        productId: '6',
        productName: 'Christmas Flower',
        image: '../images/flower.jpg'
    }

];